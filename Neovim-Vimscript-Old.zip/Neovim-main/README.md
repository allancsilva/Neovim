# Neovim
 Meu neovim em vim script 
